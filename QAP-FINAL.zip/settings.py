
class Settings:
    valid_gmail = "maayatest@gmail.com"
    valid_pass = "123qweasd456"
    valid_name = "Maaya"
    phone_number = '+79377163931'
    phone_number_wrong = '+795246358245'




